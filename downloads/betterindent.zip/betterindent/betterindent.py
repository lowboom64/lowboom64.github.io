import pyautogui
import keyboard

print("press f7 to indent")
while True:
    if keyboard.is_pressed('f7'):
        pyautogui.press('tab')
        pyautogui.press('left')
        pyautogui.press('down')