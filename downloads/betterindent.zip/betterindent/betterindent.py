import pyautogui
import keyboard

while True:
    if keyboard.is_pressed('f7'):
        pyautogui.press('tab')
        pyautogui.press('left')
        pyautogui.press('down')